module.exports = function sum_rows_mat(){

  // this function is under construction
  var row_sum = 0;
  return row_sum;
};