module.exports = function ini_zoom_info(){

  var zoom_info = {};
  zoom_info.zoom_x = 1;
  zoom_info.zoom_y = 1;
  zoom_info.trans_x = 0;
  zoom_info.trans_y = 0;

  return zoom_info;

};